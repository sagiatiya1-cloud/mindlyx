
// Paste your Firebase config here. Keep apiKey private if you prefer.
export const firebaseConfig = {
  apiKey: "<PASTE_API_KEY_HERE>",
  authDomain: "mindlyx-f3f9a.firebaseapp.com",
  projectId: "mindlyx-f3f9a",
  storageBucket: "mindlyx-f3f9a.firebasestorage.app",
  messagingSenderId: "622034178073",
  appId: "1:622034178073:web:f4613d6d13287863481a88",
  measurementId: "G-WMX18FYLEE"
};
